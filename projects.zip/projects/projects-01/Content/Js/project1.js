var cars = ["Bmw", "Audi", "Chevrolet", "Mercedes", "Nissan", "Range Rover"];

var links = document.querySelectorAll(".link-A");

for (var i = 0; i < links.length; i++) {
  const veri = links[i];
  links[i].innerHTML = cars[i];

  if (cars[i] === "Bmw") {
    
    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/bmw.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("bmw");

    });
  } else if (cars[i] === "Audi") {

    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/audi.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("audi");

    });
  } else if (cars[i] === "Chevrolet") {

    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/chevrolet.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("audi");
      
    });
  }

  else if (cars[i] === "Mercedes") {

    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/mercedes.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("audi");
      
    });
  }

  else if (cars[i] === "Nissan") {

    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/nissan.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("audi");
      
    });
  }

  else if (cars[i] === "Range Rover") {

    veri.addEventListener("mouseenter", function () {
      document.querySelector(".bg-image").style.backgroundImage =
        "url('Content/images/rangerover.jpg')";
      document.body.querySelector(".container").style = "display: block;";
      console.log("audi");
      
    });
  }

  veri.addEventListener("mouseleave", function () {
    document.body.querySelector(".container").style = "display: none;";
  });
}